!!! info "Important"
    See [Get Started](../index.md#get-started) for information on how to register
    a new app with `TickTick`


::: oauth2    
        
            
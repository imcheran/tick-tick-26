# Other Useful Methods and Info
## Time Zones

!!! info "Source"
    For a list of timezone strings, see [List of tz database time zones](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones)
    
    Acceptable Time Zone names are found under the 'TZ database name' column.

## `time_methods`

::: helpers.time_methods

## `hex_color`

::: helpers.hex_color
class HabitManager:

    def __init__(self, client_class):
        self._client = client_class
        self.access_token = ''

    #   ---------------------------------------------------------------------------------------------------------------
    #   Habit Methods
    def create(self):
        pass

    def update(self):
        pass
